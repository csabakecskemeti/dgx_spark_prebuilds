"""ctypes specific implementation of FFI"""
